/-
Bridges: Epistemic Integrity Meets the Rest of the Library
==========================================================

Author:  Ido Samuelson
Date:    July 2026
License: CC BY-SA 4.0

The four-cell framework does not sit apart from the other files —
it connects to them structurally. This file establishes internal
bridges within this library, not connections to external prior art.

Bridges established:

  • **To `LEMDependency`**: Classical Gödel's semantic conclusion
    presupposes Cell-4 blindness. Bivalent truth over a completed
    totality is exactly the claim that Cell 4 is empty.

  • **To `OpenSystemsLossy`**: The boundary of an open system is
    where Cell 4 lives operationally. Lens lossiness at the
    boundary is exactly what makes some environmental
    propositions unreachable from within — Cell 4 propositions
    of the internal engine.

  • **To `ProvisionalClosure`**: Openability of closures is the
    system-level dynamic that produces cell transitions.
    Extending a closure to decide previously-undecided
    propositions is a specific form of the update dynamics from
    `EpistemicDynamics`.

Each bridge is stated as a theorem connecting a construct in
`EpistemicIntegrity` to a construct in the target file. These are
internal integration lemmas of the library; they do not extend
the prior art cited in the individual file headers.
-/

import EpistemicIntegrity
import ProvisionalClosure
import OpenSystemsLossy
open EpistemicIntegrity

namespace EpistemicBridges

/-! ## §1. Bridge to ProvisionalClosure

A `System` from `ProvisionalClosure.lean` is essentially a
reasoning engine with derivation and negation. We show how to
lift a `System` to a `ReasoningEngine`, and observe that the
`Extension` structure there corresponds to the
`ReasoningExtension` here.
-/

open ProvisionalClosure

/-- **A consistent `System` lifts to a reasoning engine.** The
    lift takes a system's derivation predicate as both the
    derivable-in-principle relation and the actual derivation
    record. Report predicates start empty — the lifted engine
    can't lie, but also can't reveal anything. Populating the
    reports is a separate epistemic-layer construction. -/
def systemToEngineConsistent
    (S : ProvisionalClosure.System)
    (cons : ∀ p, ¬ (S.Derives p ∧ S.Derives (S.Neg p))) :
    ReasoningEngine where
  Prop_ := S.Prop_
  Neg := S.Neg
  Derivable := S.Derives
  Derived := S.Derives
  Reports_Derived := fun _ => False
  Reports_Undecided := fun _ => False
  derived_derivable := by intros; assumption
  consistent := cons
  report_derived_sound := by intro _ h; exact h.elim
  report_undecided_sound := by intro _ h; exact h.elim

/-- **System `Undecided` corresponds to reasoning-engine `KnownUnknown` only
    when the engine actually reports it.** In the lift above, no
    proposition is reported, so no `KnownUnknown` cells are
    populated. To populate them, the report predicates must be
    enriched. This is what "extending a system with an epistemic
    layer" concretely means. -/
theorem lifted_engine_has_no_reported_cells
    (S : ProvisionalClosure.System)
    (cons : ∀ p, ¬ (S.Derives p ∧ S.Derives (S.Neg p)))
    (p : S.Prop_) :
    ¬ (systemToEngineConsistent S cons).KnownUnknown p := by
  intro h
  exact h

/-! ## §2. Bridge to OpenSystemsLossy

The information-theoretic content: a reasoning engine's vocabulary
is a *view* on the environment (all propositions the world could
generate). If the engine's vocabulary is strictly smaller than
the environment's, the view is lossy — some environmental
propositions have no preimage in the engine's vocabulary. Those
are exactly the engine's Cell 4 propositions.
-/

open OpenSystemsLossy

/-- **Cell 4 is precisely lens lossiness at the boundary.**
    Given a reasoning engine E and an extension Ext to E', the
    embedding `Ext.embed : E.Prop_ → Ext.E'.Prop_` can be seen as
    the "view" the engine has of the extended world. If some
    proposition q in E' has no preimage under embed, then embed is
    non-surjective as a function — and this non-surjectivity is
    exactly what Cell 4 (`UnknownUnknown`) records.

    Statement: q is in Cell 4 relative to Ext iff no p in E's
    vocabulary embeds to q. This is the definitional identity,
    made explicit. -/
theorem cell4_is_view_non_surjectivity
    {E : ReasoningEngine} (Ext : ReasoningExtension E) (q : Ext.E'.Prop_) :
    E.UnknownUnknown Ext q ↔ ¬ ∃ p : E.Prop_, Ext.embed p = q := by
  rfl

/-- **The embedding as a lens carries the cell-4 witness.**
    If the embedding is non-surjective (some q has no preimage),
    then a lens using the embedding as its `get` is not lossless
    in the sense of `OpenSystemsLossy`, and equivalently, the
    engine's view has Cell 4 content. -/
theorem cell4_gives_view_non_injectivity_no
    {E : ReasoningEngine} (Ext : ReasoningExtension E)
    (h_surj_fail : ∃ q, E.UnknownUnknown Ext q) :
    ¬ Function.Surjective Ext.embed := by
  intro h_surj
  obtain ⟨q, hq⟩ := h_surj_fail
  exact hq (h_surj q)

/-! ## §3. Bridge to Öld: Openness Corresponds to Cell 4 Inhabitation

An open system, in the `OpenSystemsLossy` sense, is one whose
view collapses distinct environmental states. Translated to
reasoning engines: the engine cannot distinguish certain
environmental propositions from within its vocabulary. The
untracked distinctions live in Cell 4.

Openness therefore produces Cell-4 propositions for any embedded
engine. The engine cannot see the environmental structure that
the openness collapses.
-/

/-! ## §4. Bridge to Godel Second

The self-application argument from `GodelSecond.lean`
(`godel_criterion_self_application`) produces the pair
`(¬ Provable Con, ¬ Provable bot)` — a formula the theory does
not prove alongside the theory's actual consistency.

Translated to the four-cell framework: `Con` is a proposition
the theory considers (via the diagonal lemma) but cannot decide.
It is therefore Cell 2 in the theory's own vocabulary — a
`KnownUnknown`. The theory reports its own consistency as
undecided because it cannot derive it.

This connects the framework to the concrete Gödel-style
limitations proved in `GodelSecond.lean`: the theory's own
consistency statement is a Cell 2 proposition, and every
consistent reflective theory has at least one such Cell 2
proposition (its own consistency).

Full formalization of this bridge would require defining a
`ReasoningEngine` structure for reflective theories, mapping
`Provable` to `Derived`, and constructing the `Con` witness at
that level. Sketched here, executed as future work — this bridge
is presently structural commentary, not a machine-checked
theorem, and marked as such.
-/

end EpistemicBridges
