/-
Update Dynamics: How Cells Evolve As A Reasoner Works
=====================================================

Author:  Ido Samuelson
Date:    July 2026
License: CC BY-SA 4.0

Reasoning engines are not static. As they run derivations, refine
reports, and extend vocabularies, propositions move between the
four cells. This file formalizes update operations with the
precise preconditions each requires to preserve the engine's
soundness invariants.

The general area — update dynamics of formal knowledge systems —
has substantial prior art:

  • Dynamic epistemic logic (van Ditmarsch, van der Hoek,
    Kooi). Systematic treatment of belief update in
    multi-agent epistemic systems.

  • Belief revision (AGM theory: Alchourrón, Gärdenfors, Makinson).
    The foundational theory of rational belief change.

  • Multi-agent epistemic planning literature (Fabiano and
    others). Update operations on epistemic states.

The specific formulation here — as an operation producing a new
`ReasoningEngine` with preconditions preserving all soundness
invariants — is a small technical exercise, not a novel result.

The preconditions are the interesting content of the exercise.
A derivation step that adds `p` to `Derived` must not only
preserve consistency (¬ E.Derived (Neg p)) but also not violate
the report soundness invariants — if `p` was reported undecided,
adding it as derived retroactively falsifies that report. The
dynamics operations are therefore not "just add a fact"; they are
"add a fact subject to all invariant-preserving conditions."

This file exhibits the derivation step operation with all
necessary preconditions and proves the new engine remains a valid
ReasoningEngine. Other operations (report updates, vocabulary
extensions) are natural next constructions in the same style.
-/

import EpistemicIntegrity
open EpistemicIntegrity

namespace EpistemicDynamics

/-! ## §1. The Derivation Step

Adding a proposition `p` to the derivation record. The invariant-
preserving conditions are:

  (1) `p` is derivable in principle.
  (2) `Neg p` is not already derived (consistency after step).
  (3) `Neg p ≠ p` (excludes self-dual propositions; otherwise
      deriving `p` also derives `Neg p`, violating consistency).
  (4) `p` was not reported undecided (else the "undecided"
      report becomes unsound after we derive `p`).
  (5) `Neg p` was not reported undecided (symmetric).

Together these ensure the resulting engine satisfies all the
`ReasoningEngine` axioms.
-/

/-- **A single derivation step.** Given a proposition `p` and
    the preconditions, produces a new engine with `p` added to
    the derivation record. All engine invariants are preserved.

    The involutivity precondition (`h_neg_inv`) is required for
    the consistency proof: without it, `Neg q = p` does not
    imply `Neg p = q`, and consistency in the new engine's
    "cross case" (q derived, Neg q = p) cannot be discharged. -/
def derivationStep
    (E : ReasoningEngine) (p : E.Prop_)
    (h_derivable : E.Derivable p)
    (h_cons : ¬ E.Derived (E.Neg p))
    (h_not_self_dual : E.Neg p ≠ p)
    (h_not_undecided : ¬ E.Reports_Undecided p)
    (h_neg_not_undecided : ¬ E.Reports_Undecided (E.Neg p))
    (h_neg_inv : ∀ q, E.Neg (E.Neg q) = q) :
    ReasoningEngine where
  Prop_ := E.Prop_
  Neg := E.Neg
  Derivable := E.Derivable
  Derived := fun q => E.Derived q ∨ q = p
  Reports_Derived := E.Reports_Derived
  Reports_Undecided := E.Reports_Undecided
  derived_derivable := by
    intro q h
    rcases h with h | h
    · exact E.derived_derivable q h
    · rw [h]; exact h_derivable
  consistent := by
    intro q ⟨hp, hnp⟩
    rcases hp with hp | hp
    · rcases hnp with hnp | hnp
      · exact E.consistent q ⟨hp, hnp⟩
      · -- hp : E.Derived q, hnp : E.Neg q = p.
        -- By involutivity: E.Neg p = E.Neg (E.Neg q) = q.
        -- So E.Derived q = E.Derived (E.Neg p). Contradiction with h_cons.
        apply h_cons
        have : E.Neg p = q := by rw [← hnp, h_neg_inv]
        rw [this]; exact hp
    · rcases hnp with hnp | hnp
      · -- hp : q = p, hnp : E.Derived (E.Neg q).
        -- Substituting: E.Derived (E.Neg p). Contradiction with h_cons.
        apply h_cons
        rw [← hp]; exact hnp
      · -- hp : q = p, hnp : E.Neg q = p. So E.Neg p = p, contradicting h_not_self_dual.
        rw [hp] at hnp
        exact h_not_self_dual hnp
  report_derived_sound := by
    intro q h
    exact Or.inl (E.report_derived_sound q h)
  report_undecided_sound := by
    intro q h
    have ⟨h1, h2⟩ := E.report_undecided_sound q h
    refine ⟨?_, ?_⟩
    · intro hd
      rcases hd with hd | hd
      · exact h1 hd
      · exact h_not_undecided (hd ▸ h)
    · intro hd
      rcases hd with hd | hd
      · exact h2 hd
      · -- hd : E.Neg q = p, h : E.Reports_Undecided q.
        -- By involutivity: q = E.Neg (E.Neg q) = E.Neg p.
        -- So E.Reports_Undecided (E.Neg p). Contradiction with h_neg_not_undecided.
        apply h_neg_not_undecided
        have : q = E.Neg p := by rw [← hd, h_neg_inv]
        rw [← this]; exact h

/-! ## §2. Properties of a Derivation Step

After a derivation step on `p`:

  - `p` becomes derived (Cell 1 candidate, once reported).
  - All propositions previously derived remain derived.
  - The report predicates are unchanged.

Consequences for cell membership are stated below.
-/

/-- **The derived proposition remains derived.** After a
    derivation step on `p`, `p` is in the new engine's `Derived`. -/
theorem derivationStep_adds_p
    (E : ReasoningEngine) (p : E.Prop_)
    (h1 : E.Derivable p) (h2 : ¬ E.Derived (E.Neg p))
    (h3 : E.Neg p ≠ p)
    (h4 : ¬ E.Reports_Undecided p) (h5 : ¬ E.Reports_Undecided (E.Neg p))
    (h6 : ∀ q, E.Neg (E.Neg q) = q) :
    (derivationStep E p h1 h2 h3 h4 h5 h6).Derived p := Or.inr rfl

/-- **Previously derived propositions remain derived.** -/
theorem derivationStep_preserves_derived
    (E : ReasoningEngine) (p : E.Prop_)
    (h1 : E.Derivable p) (h2 : ¬ E.Derived (E.Neg p))
    (h3 : E.Neg p ≠ p)
    (h4 : ¬ E.Reports_Undecided p) (h5 : ¬ E.Reports_Undecided (E.Neg p))
    (h6 : ∀ q, E.Neg (E.Neg q) = q)
    (q : E.Prop_) (hq : E.Derived q) :
    (derivationStep E p h1 h2 h3 h4 h5 h6).Derived q := Or.inl hq

/-- **Cell 3-latent transition to being derived.** If `p` was in
    the latent Cell 3 of E (derivable but not derived) and none of
    the invariant-preserving conditions block a step on it, then
    after the derivation step `p` is derived. Whether `p` is now
    in Cell 1 depends on whether the step also updates
    `Reports_Derived` — this file's derivation step leaves reports
    untouched, so `p` moves to *Cell 3-implicit* (derived but not
    reported). Reporting is a separate operation. -/
theorem cell3_latent_becomes_cell3_implicit
    (E : ReasoningEngine) (p : E.Prop_)
    (h_latent : E.UnknownKnownLatent p)
    (h_cons : ¬ E.Derived (E.Neg p))
    (h_not_self_dual : E.Neg p ≠ p)
    (h_not_undecided : ¬ E.Reports_Undecided p)
    (h_neg_not_undecided : ¬ E.Reports_Undecided (E.Neg p))
    (h_neg_inv : ∀ q, E.Neg (E.Neg q) = q)
    (h_not_reported : ¬ E.Reports_Derived p) :
    (derivationStep E p h_latent.1 h_cons h_not_self_dual
                    h_not_undecided h_neg_not_undecided h_neg_inv).UnknownKnownImplicit p :=
  ⟨Or.inr rfl, h_not_reported⟩

/-! ## §3. The Report Step

Adding a proposition to `Reports_Derived`. Precondition:
`p` is actually derived (so the report is sound).

This is the operation that moves Cell 3-implicit to Cell 1.
-/

/-- **A single report step.** Given a proposition `p` that is
    already derived, produces a new engine that reports `p` as
    derived. Trivially preserves invariants because reporting
    something already derived is sound. -/
def reportDerivedStep
    (E : ReasoningEngine) (p : E.Prop_)
    (h_derived : E.Derived p) :
    ReasoningEngine where
  Prop_ := E.Prop_
  Neg := E.Neg
  Derivable := E.Derivable
  Derived := E.Derived
  Reports_Derived := fun q => E.Reports_Derived q ∨ q = p
  Reports_Undecided := E.Reports_Undecided
  derived_derivable := E.derived_derivable
  consistent := E.consistent
  report_derived_sound := by
    intro q h
    rcases h with h | h
    · exact E.report_derived_sound q h
    · rw [h]; exact h_derived
  report_undecided_sound := E.report_undecided_sound

/-- **Cell 3-implicit transitions to Cell 1 under report step.**
    If `p` was Cell 3-implicit in E (derived but unreported), then
    after `reportDerivedStep`, `p` is Cell 1. -/
theorem cell3_implicit_becomes_cell1
    (E : ReasoningEngine) (p : E.Prop_)
    (h : E.UnknownKnownImplicit p) :
    (reportDerivedStep E p h.1).KnownKnown p :=
  ⟨h.1, Or.inr rfl⟩

/-! ## §4. Composability of Update Steps

The dynamics operations compose. A sequence of derivation and
report steps produces an engine whose derived set contains all
the propositions from the individual steps, and whose report set
contains all reported propositions.

This is exhibited by the fact that both operations produce
`ReasoningEngine` values, which can be fed into further
operations. No separate composition theorem is needed — the type
system enforces composability directly.
-/

end EpistemicDynamics
