/-
Provisional Closure and Incompleteness as Signal
================================================

Author:  Ido Samuelson
Date:    July 2026
License: CC BY-SA 4.0

A Lean 4 formalization of the position that closure is a modeling
choice rather than an intrinsic property of systems, and that
Gödel-style undecidability marks where a system must open rather
than imposing a terminal limit on reasoning.

This position is NOT original to the author. It appears in:

  • Loasby, B. J. (2003). "Closed models and open systems."
    Journal of Economic Methodology 10:3. Develops "provisionally
    closed models" as the correct methodology for open systems.

  • Chick, V. (2003/2004). "On Open Systems." Brazilian Journal
    of Political Economy 24:1. Advocates open-systems theorising
    with "partial and temporary closures."

  • Bertalanffy, L. von (1968). "General System Theory." The
    foundational open/closed distinction.

  • arXiv 2311.10786 (2023). "A Systems-Theoretical Formalization
    of Closed Systems." Formal systems- and information-theoretic
    definitions of closure.

  • arXiv 2601.02329 (January 2026). BEDS paper. Explicitly
    conjectures Gödel-Landauer-Prigogine as a unified
    closure-produces-pathology phenomenon.

This file formalizes the position in Lean 4 with an explicit
type-theoretic construction; the position itself is a synthesis
of the above, not a novel philosophical claim.

The classical first incompleteness theorem is not treated here as a
neutral background result. It is treated as an artifact whose
scope claim overreaches — the syntactic underivability of the
Gödel sentence in PA remains a fact; the metaphysical inflation
around it does not. This audit-of-scope perspective is developed
formally in `LEMDependency.lean` and `GodelSecond.lean`, both of
which cite substantial prior art for their respective content.
does not.

Core claims formalized:
  1. Closure is provisional: every system admits an extension
     that decides any chosen proposition.
  2. Undecidability signals extension, not termination.
  3. Structural laws transfer along faithful functors (Analogy<F>).
  4. The classical incompleteness argument depends on promoting an
     UnknownUnknown to KnownKnown; systems that decline the
     promotion are not subject to the argument.
-/

namespace ProvisionalClosure

/-! ## §1. Systems -/

/-- A system: a proposition space with a derivability relation and
    an involutive negation. Deliberately minimal — no commitment to
    a completed totality of proofs, no quantification over "all
    derivations" as a settled object. -/
structure System where
  Prop_   : Type
  Derives : Prop_ → Prop
  Neg     : Prop_ → Prop_

namespace System

/-- A proposition is *undecided* in `S` when neither it nor its
    negation is derivable in the current closure of `S`. -/
def Undecided (S : System) (p : S.Prop_) : Prop :=
  ¬ S.Derives p ∧ ¬ S.Derives (S.Neg p)

/-- `T` *extends* `S` when there is an embedding of propositions
    that commutes with negation and preserves derivation. This is
    the formal shape of "opening the closure." -/
structure Extension (S T : System) where
  embed     : S.Prop_ → T.Prop_
  neg_comm  : ∀ p, embed (S.Neg p) = T.Neg (embed p)
  preserves : ∀ p, S.Derives p → T.Derives (embed p)

/-! ## §2. The Openability Principle -/

/-- **Openability of the Undecided.** Every proposition that is
    undecided in a system admits an extension of that system that
    decides it. Closure is not terminal: undecidability is a signal
    for extension.

    This is asserted axiomatically: it is the position under
    formalization. A framework that treats some closure as
    metaphysically final would reject this axiom. The formalization
    does not attempt to prove that framework wrong, only to display
    the alternative as coherent.

    Note: the hypothesis `Undecided S p` is essential to the
    philosophical content. A stronger axiom permitting extension
    for *any* proposition would be trivially true — you can always
    add p as an axiom — and would not express the substantive
    claim about undecidability. -/
axiom openable (S : System) (p : S.Prop_) (_hu : S.Undecided p) :
    ∃ (T : System) (h : Extension S T),
      T.Derives (h.embed p) ∨ T.Derives (T.Neg (h.embed p))

/-! ## §3. Incompleteness as Signal -/

/-- **Corollary (No Terminal Closure).**
    If S has any undecided proposition, S admits a proper
    extension deciding it. Terminality of closure is inconsistent
    with the existence of any undecided proposition. -/
theorem no_terminal_closure
    (S : System) (h : ∃ p : S.Prop_, S.Undecided p) :
    ∃ (T : System) (_e : Extension S T),
      ∃ q : T.Prop_, T.Derives q ∨ T.Derives (T.Neg q) := by
  obtain ⟨p, hu⟩ := h
  obtain ⟨T, e, hdec⟩ := openable S p hu
  exact ⟨T, e, e.embed p, hdec⟩

end System

open System

/-! ## §4. Structural Transfer via Functors (Analogy<F>) -/

/-- A faithful functor between systems: preserves negation and
    derivation. Encodes the pr4xis `Analogy<F>` posture — analogy
    as a checkable structural map, not a rhetorical suggestion. -/
structure SysFunctor (S T : System) where
  map      : S.Prop_ → T.Prop_
  neg_comm : ∀ p, map (S.Neg p) = T.Neg (map p)
  faithful : ∀ p, S.Derives p → T.Derives (map p)

/-! Note: `SysFunctor.faithful` is itself the statement that faithful
    functors preserve derivation. No separate theorem is needed to
    express this fact — the field's type IS the theorem. Calling
    `F.faithful p` at any use site is the operation of transporting
    a derivation from S to T through the functor. -/

/-! ## §5. Trichotomy of Infinities -/

/-- The kind of unboundedness attaching to a domain.

    * `KnownUnknown`:   rule-governed unbounded extension; law in hand.
    * `UnknownKnown`:   structure operative but not yet articulated.
    * `UnknownUnknown`: no rule, no articulation, no legitimate totality.
    -/
inductive InfKind
  | KnownUnknown
  | UnknownKnown
  | UnknownUnknown
  deriving DecidableEq

/-- The move underlying the strong reading of classical
    incompleteness: promoting an `UnknownUnknown` to the status of
    a settled totality (a `KnownKnown`). This is the metaphysical
    grant — completed ℕ, "all proofs" as a determinate object,
    LEM over infinite domains — that the classical argument
    inherits from its surrounding framework. -/
def IllegitimatePromotion : InfKind → Prop
  | InfKind.UnknownUnknown => True
  | _                      => False

/-- A `Sound` system is one that refuses the illegitimate promotion:
    every unboundedness it admits is either a rule-governed process
    or an unarticulated structure, never a completed totality
    dressed up as a known object. -/
def Sound (kinds : List InfKind) : Prop :=
  ∀ k ∈ kinds, ¬ IllegitimatePromotion k

/-- Sound systems do not admit the classical construction. -/
theorem sound_excludes_completed_totality
    (kinds : List InfKind) (hs : Sound kinds) :
    ∀ k ∈ kinds, k ≠ InfKind.UnknownUnknown := by
  intro k hk hEq
  have : IllegitimatePromotion k := by
    rw [hEq]; exact True.intro
  exact hs k hk this

/-! ## §6. The Theorem Applied to Itself

The classical first incompleteness theorem defines incompleteness as
the presence, within a system, of true statements the system cannot
prove from within. Applied honestly to itself, the theorem fails its
own criterion.

The classical proof requires:

  (i)  quantification over ℕ as a completed totality,
  (ii) LEM over that totality (every proof either exists or does not),
  (iii) the standard model as a determinate object of reference.

None of (i), (ii), (iii) is proved within the theorem's own machinery.
Each is imported from a surrounding platonist framework and treated as
neutral background. The legitimacy of the completed totality is a
*true statement, in the framework, that the framework does not prove
from within* — which is the exact shape the theorem names as
incompleteness.

Therefore, by its own definition, the classical incompleteness
theorem is incomplete on its surface. It sits inside the same
epistemic structure it claims to diagnose and inherits the same
limits, without acknowledging that it does so.

This does not overturn the syntactic result — PA does not decide
its Gödel sentence, and that remains true. What collapses is the
scope claim: the theorem does not stand above the systems it
describes. It is one such system, subject to its own verdict,
carrying an unexamined metaphysical commitment as its unproven
foundation. -/

/-- The theorem's unexamined dependencies. Each is a proposition the
    classical argument requires but does not derive within itself.
    Enumerated here as an inductive type so the audit is
    machine-inspectable; this file does *not* prove the underivability
    claim — that is done in `GodelSecond.lean` via Löb's theorem
    and the second incompleteness theorem. -/
inductive UnprovenDependency
  | CompletedNaturals              -- ℕ as a settled totality
  | LEMOverInfiniteDomains         -- excluded middle over unbounded quantifiers
  | StandardModelDeterminate       -- a unique intended interpretation
  deriving DecidableEq

/-- The classical incompleteness argument depends on all three. -/
def classicalDependencies : List UnprovenDependency :=
  [ .CompletedNaturals
  , .LEMOverInfiniteDomains
  , .StandardModelDeterminate ]

/-- **On the self-application argument (pointer, not proof).**

    The philosophical claim of this section — that the classical
    incompleteness theorem, by its own criterion, applies to
    itself — is *not* discharged by this file. This file only
    enumerates the dependencies of the classical argument as data.

    The substantive proof is in `GodelSecond.lean`:

      • `lob` — Löb's theorem, from HBL and diagonal.
      • `godel_second` — Gödel's second incompleteness theorem.
      • `godel_criterion_self_application` — any consistent
        reflective theory produces an unprovable-yet-true pair:
        its consistency statement (unprovable in the theory) and
        its actual consistency (true by hypothesis). This is
        precisely the pattern Gödel's first theorem uses as its
        criterion for incompleteness.

    Framework capable of proving Gödel's first theorem ⟹ framework
    satisfies HBL ⟹ framework satisfies its own criterion. The
    chain is machine-checked in `GodelSecond.lean`; this file
    merely points at it. -/
def selfApplicationPointer : String :=
  "See GodelSecond.lean : lob, godel_second, godel_criterion_self_application"



/-! ## §7. Concluding Remark

The formalization exhibits a coherent posture:

  • Systems have provisional closures, not intrinsic ones.
  • Undecidability signals extension, not termination.
  • Structural laws transfer along faithful functors.
  • Unboundedness need not be a completed totality.
  • The classical incompleteness theorem, by its own criterion,
    fails its own criterion.

The syntactic result stands: PA does not decide its Gödel sentence.
What does not stand is the scope claim — that this local fact about
one class of formal systems tells us anything universal about
reasoning, knowledge, or systems in general. The theorem is a local
diagnostic dressed up as a global limit, and the dress-up is
supplied by the completed-infinity premise it inherits without
justification.

pr4xis operates in the region where none of this bites. Ontologies
are closures-in-use. Property verification samples state space
governed by an operational law. Analogy<F> transports structure
along checkable functors. PipelineTrace renders derivations
inspectable rather than certifying the closure consistent from
within. None of this evades Gödel — it declines the configuration
that produces the pathology, and refuses the metaphysical grant
that makes the pathology look profound.
-/

end ProvisionalClosure
