# Provisional Closure

**Author:** Ido Samuelson
**License:** CC BY-SA 4.0
**Date:** July 2026
**Lean version:** 4.32.0 (vanilla, no Mathlib dependency)

Ten machine-checked Lean 4 files formalizing a curated integration of established positions on formal systems, closure, incompleteness, and epistemic self-report. Every file compiles cleanly under vanilla Lean 4.32.0. No `sorry`, no `admit`. Every theorem's hypotheses are essential to its conclusion.

## What This Is

A pedagogical formalization and integration of standard proof-theoretic and systems-theoretic results, packaged as a Lean 4 library with a specific application to reasoning-engine architecture. The mathematical content is derivative — every theorem could be extracted from existing formalizations or textbooks — but the integration into one machine-checked library, with a specific focus on reasoning-engine epistemic self-report, may be useful as a reference.

## What This Is Not

Novel mathematics. The philosophical position — that Gödel's incompleteness is diagnostic of open-being-treated-as-closed, that closure is provisional, that epistemic self-report requires acknowledging all four cells of the knowledge/awareness taxonomy — has substantial prior art. This library assembles the machine-checkable content of that position; it does not originate the position.

## Prior Art

The specific philosophical claims formalized here are established positions with multiple attributions:

**Provisional closure of open systems (Loasby 2003, Chick 2003):** Brian Loasby's "Closed models and open systems" (*Journal of Economic Methodology* 10:3) and Victoria Chick's "On Open Systems" both develop the framing that open systems are usefully studied through "provisionally closed models" — closure as a modeling choice rather than an intrinsic property. This economic-methodology tradition traces back through the post-Keynesian literature. See also Bertalanffy's general systems theory and Prigogine's dissipative structures for the systems-theoretic root.

**Systems-theoretical formalization of closure (arXiv 2311.10786, 2023):** Provides formal systems- and information-theoretic definitions of closure, including functional closure and informational closure. Directly formalizes the closed-vs-open distinction we use.

**Gödel-openness conjecture (arXiv 2601.02329, January 2026):** The "BEDS" paper explicitly conjectures the Gödel-Landauer-Prigogine trilemma: incompleteness in formal systems, thermodynamic cost of irreversible computation, and entropy increase in closed thermodynamic systems as structurally related phenomena where "closure produces pathology, openness resolves it." This is almost exactly the claim about Gödel and openness developed here, published six months before this library.

**Openness ≡ information loss (Willems, Hedges, Stein & Samuelson):** Jan Willems' theory of open stochastic systems, Jules Hedges' "Coherence for lenses and open games" (arXiv 1704.02230, 2017) and its notion of teleological categories, and Stein & Samuelson's "A Categorical Treatment of Open Linear Systems" (arXiv 2403.03934, 2024) all develop the category-theoretic framework in which openness corresponds to information loss at the boundary.

**LEM-dependency of classical Gödel (Kleene 1952, Steinmetz 2015):** Kleene's *Introduction to Metamathematics* systematically identifies the LEM-dependent steps in classical Gödel arguments. Steinmetz's "An Intuitively Complete Analysis of Gödel's Incompleteness" (2015, arXiv 1512.03667) specifically examines the constructive/intuitionistic acceptability of Gödel's proof. This library restates known results.

**Gödel's second incompleteness via Löb + HBL:** Standard modern presentation, formalized multiple times:
- **FormalizedFormalLogic/Foundation** (Lean 4, ongoing): Full formalization including HBL, Löb, and Gödel's second for arithmetic theories stronger than IΣ₁. This project supersedes our `GodelSecond.lean` in scope.
- **Maggesi & Perini Brogi 2020** (HOL Light): "Mechanising Gödel–Löb Provability Logic in HOL Light."
- **O'Connor 2005** (Coq): "Essential Incompleteness of Arithmetic Verified by Coq." ~3000 lines with full arithmetization.
- **Paulson 2013** (Isabelle): "A Machine-Assisted Proof of Gödel's Incompleteness Theorems for the Theory of Hereditarily Finite Sets."

The mathematical content of `GodelSecond.lean` is a stripped-down abstract version of these formalizations.

**The Rumsfeld four-cell taxonomy:** Widely used in decision theory, risk management, national security, medical research. The "unknown known" traces to Socrates. Nassim Taleb's *The Black Swan* (2007) uses it. Nova Spivack's "Epistemology and Metacognition in Artificial Intelligence" (2025) develops it for AI systems. No dedicated proof-assistant formalization of it as a self-report structure for reasoning engines that we could find, which is where `EpistemicIntegrity.lean` may make a modest contribution.

**Reflection and self-application of Gödel's theorem:** Standard proof theory. Torkel Franzén's *Gödel's Theorem: An Incomplete Guide to Its Use and Abuse* (2005), Boolos's *The Logic of Provability* (1993), Smoryński's *Self-Reference and Modal Logic* (1985), Feferman's reflection progressions (1962 onward). The self-application argument formalized in `godel_criterion_self_application` is textbook material.

**Fixed-point theorems for AI reflection (arXiv 2509.06055, 2025):** "Fixed-Point Theorems and the Ethics of Radical Transparency: A Logic-First Treatment" uses Löb's theorem for AI systems reasoning about themselves. Overlaps substantively with `ReflectiveReasoner.lean`.

**AI hallucination and epistemic boundary work:** Very active current research including Delineating Knowledge Boundaries for Honest LVLMs (2026), Epistemic Alignment framework (2025), Knowledge Consistent Alignment (2024), and many others. `EpistemicIntegrity.lean` connects to this work but does not extend it in a novel technical direction.

## What The Author Contributes

Given the extensive prior art, the specific contributions of this library are:

1. **A machine-checked integration.** Ten Lean 4 files that compile together and interact cleanly, packaging the above positions as one inspectable artifact. The integration itself is the contribution, not the individual results.

2. **A specific application to reasoning-engine architecture.** The four-cell framework is applied here to reasoning engines as an epistemic-integrity requirement, with concrete witnesses (`HonestReasonerExists.lean`), an audit function (`ReflectiveReasoner.lean`), and connections to update dynamics (`EpistemicDynamics.lean`). This application may support engineering work on reasoning-engine self-report.

3. **The two-form Cell 3 distinction.** The formal distinction between `UnknownKnownImplicit` (derived but unreported) and `UnknownKnownLatent` (derivable but not derived), with a proof of their disjointness, may not appear in prior literature in exactly this form. Small contribution.

4. **A concrete stopping point.** The library provides a fixed reference implementation someone can point to, verify locally, cite, or extend.

## The Files

### `ProvisionalClosure.lean` — Systems Framework

Formalizes systems as proposition spaces with derivation and negation, extensions as embeddings, and functors as structural maps. The `openable` axiom asserts that every system admits an extension deciding any chosen proposition. Axiomatizes Loasby-Chick provisional closure at the type-theoretic level.

### `OpenSystemsLossy.lean` — Openness ≡ Interface Lossiness

Very-well-behaved lenses, losslessness (get injective), openness (view collapses distinct source states), and the theorem that openness is equivalent to lens lossiness. Formalizes what Willems and Hedges develop in their categorical treatments; presents it in a form suited to the reasoning-engine application.

### `LEMDependency.lean` — Audit of Classical Semantic Gödel

Isolates the LEM-dependent step in the classical semantic conclusion of Gödel's first theorem. The syntactic underivability of G is constructive; the "G is true but unprovable" upgrade requires a bivalent truth predicate whose neg_true clause is essentially LEM localized to the sentence level. Formalizes Kleene/Steinmetz analysis in Lean 4.

### `GodelSecond.lean` — Löb, Gödel's Second, Self-Application

Standard abstract HBL + Löb + Gödel's second, with the self-application argument packaged as `godel_criterion_self_application`. Stripped-down version of what already exists in FormalizedFormalLogic/Foundation and elsewhere.

### `EpistemicIntegrity.lean` — Four-Cell Framework

Formalizes the Rumsfeld taxonomy as a structural requirement on reasoning engines: `KnownKnown`, `KnownUnknown`, `UnknownKnownImplicit`, `UnknownKnownLatent`, and `UnknownUnknown` (relative to an extension). Proves that engines dropping specific cells silently fall into named failure modes. May be one of the first Lean formalizations of this specific structure.

### `HonestReasonerExists.lean` — Concrete Witness

A concrete `ReasoningEngine` E over signed atoms of {A, B, C} plus extension adding D, with proved witnesses in all four cells. Turns the framework from a specification into a specification-with-witnesses.

### `ReflectiveReasoner.lean` — Audit Function

Adds an audit function returning a `CellClassification` for each proposition, plus a soundness condition. Constructs the audit function for the concrete engine and proves it sound. Self-application produces a regress: reflective reasoners audit propositions, but reasoning *about* the audit function itself requires a meta-reasoner. Overlaps with arXiv 2509.06055.

### `EpistemicComposition.lean` — Categorical Structure

Identity and composition of extensions, faithful functors between engines, cell membership transfer along functors. Standard category-theoretic constructions.

### `EpistemicDynamics.lean` — Update Steps

Derivation steps and report steps as operations producing new engines, with the invariant-preserving preconditions each requires. Cell transitions under stepping.

### `EpistemicBridges.lean` — Internal Connections

Bridges between the framework files: `ReasoningEngine` from `EpistemicIntegrity` connects to `System` from `ProvisionalClosure` via a consistent-system lift; `UnknownUnknown` is exhibited as embedding non-surjectivity, connecting to `OpenSystemsLossy`.

## Verification

```bash
# Install elan (Lean toolchain manager)
curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh | sh -s -- -y

# Set Lean version
elan toolchain install leanprover/lean4:v4.32.0
elan default leanprover/lean4:v4.32.0

# Compile (silent = success)
lean ProvisionalClosure.lean
lean OpenSystemsLossy.lean
lean LEMDependency.lean
lean GodelSecond.lean
lean EpistemicIntegrity.lean
lean HonestReasonerExists.lean       # depends on EpistemicIntegrity
lean ReflectiveReasoner.lean         # depends on above two
lean EpistemicComposition.lean
lean EpistemicDynamics.lean
lean EpistemicBridges.lean
```

All ten files compile with exit code 0. No warnings. Classical logic is used only where genuinely needed (a few `Classical.byContradiction` applications, invoked explicitly rather than via tactic sugar). `GodelSecond.lean` uses no classical logic.

## Honest Positioning

If citing this library:

> Samuelson, I. (2026). *Provisional Closure: A Lean 4 formalization synthesizing established positions on systems closure, incompleteness, and epistemic self-report for reasoning engines.* Available at [repository URL].

If describing what the library does:
- **Do say:** "A machine-checked pedagogical integration of standard proof-theoretic and systems-theoretic positions, applied to reasoning-engine self-report."
- **Do say:** "A curated Lean 4 library synthesizing prior work by Loasby, Chick, Willems, Hedges, Kleene, Steinmetz, and others into one inspectable artifact."
- **Don't say:** "A novel result about Gödel's incompleteness theorem."
- **Don't say:** "New foundational contribution to systems theory."
- **Don't say:** "Original solution to the epistemic-integrity problem for AI systems."

The value of this library is real but modest. It exists as a fixed reference implementation someone can compile, verify, and extend. That's what it is; that's what it should be called.

## Acknowledgments

This library is a direct debt to Brian Loasby (provisional closure), Victoria Chick (open-systems methodology), Jan Willems (open systems), Jules Hedges (teleological categories), Stephen Kleene (constructive proof theory), Jason Steinmetz (constructive analysis of Gödel), George Boolos (provability logic), Torkel Franzén (careful use of Gödel's theorem), the FormalizedFormalLogic team (Lean 4 Gödel formalization), and the BEDS paper authors (Gödel-Landauer-Prigogine conjecture). None of the philosophical claims are original to the author; the assembly is.
