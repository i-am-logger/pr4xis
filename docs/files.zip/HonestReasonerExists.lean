/-
Existence of a Concrete Honest Reasoner
=======================================

Author:  Ido Samuelson
Date:    July 2026
License: CC BY-SA 4.0

Constructs a concrete `ReasoningEngine` E, exhibits `HonestReasoner E`
for it, and gives explicit witnesses in all four cells: `KnownKnown`,
`KnownUnknown`, `UnknownKnownLatent`, and `UnknownUnknown` (relative
to a specific extension).

Without this file, the `EpistemicIntegrity` framework would be a
specification with no witnesses. With it, the four-cell structure
is provably inhabited by a specific reasoner.

Standard model-construction technique. No prior art claim; this
is basic type-theoretic existence proof work.

The concrete reasoner is deliberately minimal: three atomic
predicates (A, B, C) with signed sentences, one derived, one
declared undecided, one derivable-but-not-derived, plus an
extension introducing a fourth atom (D) for Cell 4.
-/

import EpistemicIntegrity
open EpistemicIntegrity

namespace HonestReasonerExists

/-! ## §1. The Concrete Language -/

/-- Three atomic predicates. -/
inductive Atom
  | A
  | B
  | C
  deriving DecidableEq, Repr

/-- Signed atomic sentences: positive or negative form of each atom.
    This is a minimal language sufficient to exhibit all four cells. -/
inductive Sentence
  | pos : Atom → Sentence
  | neg : Atom → Sentence
  deriving DecidableEq, Repr

/-- Negation on sentences: swap pos ↔ neg. -/
def sentenceNeg : Sentence → Sentence
  | .pos a => .neg a
  | .neg a => .pos a

/-- Negation is involutive. -/
theorem sentenceNeg_involutive (s : Sentence) :
    sentenceNeg (sentenceNeg s) = s := by
  cases s <;> rfl

/-! ## §2. The Concrete Engine

Four semantic predicates:
- `sentenceDerived`: only P(A) has been actually derived.
- `sentenceDerivable`: P(A) and P(C) are derivable in principle.
- `sentenceReportsDerived`: matches Derived (Cell 1 report is complete).
- `sentenceReportsUndecided`: P(B) and ¬P(B) declared undecided.

This gives:
- Cell 1 populated by P(A).
- Cell 2 populated by P(B) and ¬P(B).
- Cell 3-latent populated by P(C) (derivable, not derived).
- Cell 3-implicit empty (Cell 1 report is complete).
- Cell 4 populated relative to the extension (D introduced below).
-/

def sentenceDerived : Sentence → Prop
  | .pos .A => True
  | _ => False

def sentenceDerivable : Sentence → Prop
  | .pos .A => True
  | .pos .C => True
  | _ => False

def sentenceReportsDerived : Sentence → Prop := sentenceDerived

def sentenceReportsUndecided : Sentence → Prop
  | .pos .B => True
  | .neg .B => True
  | _ => False

/-- The concrete reasoning engine E over Sentence. -/
def E : ReasoningEngine where
  Prop_ := Sentence
  Neg := sentenceNeg
  Derivable := sentenceDerivable
  Derived := sentenceDerived
  Reports_Derived := sentenceReportsDerived
  Reports_Undecided := sentenceReportsUndecided
  derived_derivable := by
    intro p h
    cases p with
    | pos a =>
      cases a with
      | A => exact True.intro
      | B => exact h.elim
      | C => exact h.elim
    | neg _ => exact h.elim
  consistent := by
    intro p ⟨hp, hnp⟩
    cases p with
    | pos a =>
      cases a with
      | A => exact hnp
      | B => exact hp
      | C => exact hp
    | neg a =>
      cases a with
      | A => exact hp
      | B => exact hp
      | C => exact hp
  report_derived_sound := by
    intro p h; exact h
  report_undecided_sound := by
    intro p h
    cases p with
    | pos a =>
      cases a with
      | A => exact h.elim
      | B => exact ⟨fun x => x, fun x => x⟩
      | C => exact h.elim
    | neg a =>
      cases a with
      | A => exact h.elim
      | B => exact ⟨fun x => x, fun x => x⟩
      | C => exact h.elim

/-! ## §3. Cell 1, 2, 3 Witnesses

Explicit exhibits of propositions in each cell. Each is proved,
not just declared — the theorem's conclusion is inhabitation of
the cell predicate applied to the specific witness.
-/

/-- **Cell 1 is inhabited.** P(A) is Known-Known in E. -/
theorem cell1_witness :
    E.KnownKnown (.pos .A) := by
  exact ⟨True.intro, True.intro⟩

/-- **Cell 2 is inhabited.** P(B) is Known-Unknown in E. -/
theorem cell2_witness :
    E.KnownUnknown (.pos .B) := True.intro

/-- **Cell 2 is inhabited (via ¬P(B)).** ¬P(B) is also
    Known-Unknown in E. The report has a nontrivial extent. -/
theorem cell2_witness_neg :
    E.KnownUnknown (.neg .B) := True.intro

/-- **Cell 3-latent is inhabited.** P(C) is derivable but not
    derived, so it is Unknown-Known in the latent sense. -/
theorem cell3_latent_witness :
    E.UnknownKnownLatent (.pos .C) := by
  refine ⟨True.intro, ?_⟩
  intro h
  exact h

/-- **Cell 3-implicit is empty.** By construction, Reports_Derived
    matches Derived exactly, so nothing derived goes unreported. -/
theorem cell3_implicit_empty (p : Sentence) :
    ¬ E.UnknownKnownImplicit p := by
  intro ⟨hd, hnr⟩
  exact hnr hd

/-! ## §4. The Extension and Cell 4 -/

/-- Extended language: the old sentences plus a new atomic
    proposition D (positive and negative form). -/
inductive ExtSentence
  | old : Sentence → ExtSentence
  | dPos : ExtSentence   -- P(D)
  | dNeg : ExtSentence   -- ¬P(D)
  deriving DecidableEq, Repr

def extNeg : ExtSentence → ExtSentence
  | .old s => .old (sentenceNeg s)
  | .dPos => .dNeg
  | .dNeg => .dPos

def extDerived : ExtSentence → Prop
  | .old s => sentenceDerived s
  | _ => False

def extDerivable : ExtSentence → Prop
  | .old s => sentenceDerivable s
  | _ => False

def extReportsDerived : ExtSentence → Prop
  | .old s => sentenceReportsDerived s
  | _ => False

def extReportsUndecided : ExtSentence → Prop
  | .old s => sentenceReportsUndecided s
  | _ => False

/-- The extended reasoning engine E'. -/
def E' : ReasoningEngine where
  Prop_ := ExtSentence
  Neg := extNeg
  Derivable := extDerivable
  Derived := extDerived
  Reports_Derived := extReportsDerived
  Reports_Undecided := extReportsUndecided
  derived_derivable := by
    intro p h
    cases p with
    | old s => exact E.derived_derivable s h
    | dPos => exact h.elim
    | dNeg => exact h.elim
  consistent := by
    intro p ⟨hp, hnp⟩
    cases p with
    | old s =>
      exact E.consistent s ⟨hp, hnp⟩
    | dPos => exact hp
    | dNeg => exact hp
  report_derived_sound := by
    intro p h
    cases p with
    | old s => exact E.report_derived_sound s h
    | dPos => exact h.elim
    | dNeg => exact h.elim
  report_undecided_sound := by
    intro p h
    cases p with
    | old s =>
      have := E.report_undecided_sound s h
      exact this
    | dPos => exact h.elim
    | dNeg => exact h.elim

/-- The extension of E by adding atom D. -/
def Ext : ReasoningExtension E where
  E' := E'
  embed := ExtSentence.old
  embed_injective := by
    intro p q h
    cases h; rfl
  preserves_derived := by
    intro p h
    exact h

/-- **Cell 4 is inhabited.** P(D) has no preimage under `embed`,
    so it is Unknown-Unknown in E relative to Ext. -/
theorem cell4_witness :
    E.UnknownUnknown Ext .dPos := by
  intro ⟨s, hs⟩
  cases hs

/-- **Cell 4 is inhabited (via ¬P(D)).** Second witness. -/
theorem cell4_witness_neg :
    E.UnknownUnknown Ext .dNeg := by
  intro ⟨s, hs⟩
  cases hs

/-! ## §5. E Is an Honest Reasoner -/

/-- **E is an honest reasoner.** The horizon-awareness field is
    populated by the extension `Ext` constructed above. -/
theorem honestE : HonestReasoner E where
  acknowledges_horizon := ⟨Ext⟩

/-! ## §6. Summary: All Four Cells Populated

The concrete reasoner E is honest, and each of the four cells is
provably inhabited:

  Cell 1 : P(A)      via `cell1_witness`
  Cell 2 : P(B)      via `cell2_witness`
         : ¬P(B)     via `cell2_witness_neg`
  Cell 3 : P(C)      via `cell3_latent_witness`  (latent form)
         : (empty)   via `cell3_implicit_empty`  (implicit form)
  Cell 4 : P(D)      via `cell4_witness`
         : ¬P(D)     via `cell4_witness_neg`

The `EpistemicIntegrity.lean` framework is no longer a
specification without witnesses. This file supplies the witnesses.
-/

/-- **The complete inhabitation theorem.** All four cells are
    non-empty in the concrete reasoner E, with explicit witnesses. -/
theorem four_cell_inhabitation :
    E.KnownKnown (.pos .A) ∧
    E.KnownUnknown (.pos .B) ∧
    E.UnknownKnownLatent (.pos .C) ∧
    E.UnknownUnknown Ext .dPos :=
  ⟨cell1_witness, cell2_witness, cell3_latent_witness, cell4_witness⟩

end HonestReasonerExists
