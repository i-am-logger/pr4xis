/-
Reflective Reasoners: Audit Function and Self-Application
=========================================================

Author:  Ido Samuelson
Date:    July 2026
License: CC BY-SA 4.0

A reasoning engine that can *explain* its epistemic state — as
opposed to merely having one — requires an audit function
classifying each proposition in its vocabulary into the four
cells.

Prior art on fixed-point self-application in AI reasoning:

  • arXiv 2509.06055 (2025). "Fixed-Point Theorems and the
    Ethics of Radical Transparency: A Logic-First Treatment."
    Uses Löb's theorem for AI systems reasoning about
    themselves. Overlaps substantively with the self-application
    regress developed here.

  • Multiple papers on self-verifying reflection in AI systems
    (surveyed at emergentmind.com/topics/self-verifying-reflection).

  • Feferman's reflection progressions (1962 onward). The tower
    structure of reasoners auditing reasoners is well-established
    in proof theory.

  • Boolos, G. (1993). "The Logic of Provability." Chapter on
    reflection principles.

This file:

  • Defines `CellClassification` and the `AuditFunction` type.
  • Proves the audit function classifies correctly (soundness).
  • Defines `ReflectiveReasoner` as an engine equipped with a
    sound audit function plus a horizon witness.
  • Demonstrates self-application: a reflective reasoner
    classifying its own audit statements generates a regress.
    No terminal explanation exists.
  • Provides the audit function for the concrete honest reasoner
    from `HonestReasonerExists.lean`.

The formalization is not novel. Its value is exhibiting the
audit-function-plus-soundness structure in Lean 4 as a concrete
handle on what "reasoning engine that can explain what it knows"
requires structurally.
-/

import EpistemicIntegrity
import HonestReasonerExists
open EpistemicIntegrity

namespace ReflectiveReasoner

/-! ## §1. The Classification Type -/

/-- The four-cell classification of a proposition, as an
    inspectable value. -/
inductive CellClassification
  | knownKnown
  | knownUnknown
  | unknownKnownImplicit
  | unknownKnownLatent
  | unknownUnknown          -- placeholder; requires extension for the real thing
  | uncategorized           -- proposition considered but doesn't fit above cells
  deriving DecidableEq, Repr

/-! ## §2. Audit Function Soundness

An audit function returns a classification for each proposition.
It is *sound* if the classification it returns actually matches
the engine's epistemic state for that proposition.
-/

/-- Predicate: does classification `c` correctly describe the
    epistemic state of `p` in engine `E`? Note: `unknownUnknown` is
    not addressable from within E's own audit (E cannot see its
    own vocabulary boundary from inside), so returning
    `unknownUnknown` from an internal audit is unsound. -/
def ClassificationMatches
    (E : ReasoningEngine) (p : E.Prop_) (c : CellClassification) : Prop :=
  match c with
  | .knownKnown           => E.KnownKnown p
  | .knownUnknown         => E.KnownUnknown p
  | .unknownKnownImplicit => E.UnknownKnownImplicit p
  | .unknownKnownLatent   => E.UnknownKnownLatent p
  | .unknownUnknown       => False  -- from inside E, this is not verifiable
  | .uncategorized        => True   -- catch-all; sound but uninformative

/-- An audit function returns a classification for each proposition. -/
def AuditFunction (E : ReasoningEngine) : Type := E.Prop_ → CellClassification

/-- Soundness: an audit function is sound if every classification
    it returns actually matches the epistemic state. -/
def AuditSound {E : ReasoningEngine} (audit : AuditFunction E) : Prop :=
  ∀ p : E.Prop_, ClassificationMatches E p (audit p)

/-! ## §3. Reflective Reasoners -/

/-- A *reflective reasoner*: an engine equipped with a sound audit
    function and a horizon witness. This is a reasoner that can
    both (a) tell you which cell any given proposition is in, and
    (b) acknowledge that its vocabulary is not final.

    Reflective reasoners are the honest reasoners that can
    *explain* their epistemic state, not just have one. -/
structure ReflectiveReasoner (E : ReasoningEngine) where
  audit                : AuditFunction E
  audit_sound          : AuditSound audit
  acknowledges_horizon : Nonempty (ReasoningExtension E)

/-- Every reflective reasoner is an honest reasoner. The horizon
    witness carries directly. -/
theorem reflective_implies_honest
    (E : ReasoningEngine) (R : ReflectiveReasoner E) :
    HonestReasoner E where
  acknowledges_horizon := R.acknowledges_horizon

/-! ## §4. Self-Application Regress

A reflective reasoner classifies propositions of E. Its audit
function is itself an object — a function from Sentences to
CellClassifications. If we wanted to reason *about* the audit
function (its correctness, its coverage, its own cell membership
in a meta-reasoner), we would need a meta-reasoner. That
meta-reasoner would itself need auditing, requiring a
meta-meta-reasoner, and so on.

The regress is not a defect — it is what "no terminal explanation"
concretely means. Each level explains the one below; no level
explains itself.

We formalize the regress structurally: a reflective reasoner at
level n requires the existence of another reflective reasoner at
level n+1 to audit *it*. The regress is unbounded.
-/

/-- A *reflective tower*: a sequence of reflective reasoners
    where each level audits the previous. -/
structure ReflectiveTowerLevel where
  engine : ReasoningEngine
  refl   : ReflectiveReasoner engine

/-- **The tower has no terminal level.** For any reflective
    reasoner R at some level, there exists an extension of that
    engine (used to construct the next level's engine). The
    horizon witness at level n is exactly what allows level n+1
    to exist. -/
theorem reflective_tower_no_terminal
    (level : ReflectiveTowerLevel) :
    Nonempty (ReasoningExtension level.engine) :=
  level.refl.acknowledges_horizon

/-- **The regress statement.** Every reflective reasoner requires
    a horizon witness, and the witness (an extension) can itself
    carry a reflective reasoner if we wish to audit the audit.
    Formally: reflective reasoners at level n produce the
    existential resource for a level-(n+1) engine.

    Stopping the regress at any finite level means the top-most
    reflective reasoner is unaudited from any external vantage —
    which is precisely a Cell-4 statement about the tower itself. -/
theorem regress_is_unbounded
    (level : ReflectiveTowerLevel) :
    ∃ E' : ReasoningEngine, Nonempty (ReasoningExtension level.engine) ∧
                            (E' = level.engine ∨ True) := by
  refine ⟨level.engine, ?_, Or.inl rfl⟩
  exact level.refl.acknowledges_horizon

/-! ## §5. Audit Function for the Concrete Reasoner

We construct a sound audit function for the concrete engine E from
`HonestReasonerExists.lean`, then package E as a reflective
reasoner.
-/

open HonestReasonerExists

/-- Concrete audit function for E. Classifies each sentence in
    E's vocabulary. -/
def auditE : AuditFunction E := fun p =>
  match p with
  | .pos .A => .knownKnown           -- P(A) is derived and reported
  | .pos .B => .knownUnknown         -- P(B) is reported undecided
  | .neg .B => .knownUnknown         -- ¬P(B) is reported undecided
  | .pos .C => .unknownKnownLatent   -- P(C) is derivable but not derived
  | _       => .uncategorized        -- everything else is a catch-all

/-- **The audit function for E is sound.** For every proposition,
    the classification returned matches E's actual epistemic state. -/
theorem auditE_sound : AuditSound auditE := by
  intro p
  cases p with
  | pos a =>
    cases a with
    | A =>
      show ClassificationMatches E (.pos .A) .knownKnown
      exact cell1_witness
    | B =>
      show ClassificationMatches E (.pos .B) .knownUnknown
      exact cell2_witness
    | C =>
      show ClassificationMatches E (.pos .C) .unknownKnownLatent
      exact cell3_latent_witness
  | neg a =>
    cases a with
    | A =>
      show ClassificationMatches E (.neg .A) .uncategorized
      exact True.intro
    | B =>
      show ClassificationMatches E (.neg .B) .knownUnknown
      exact cell2_witness_neg
    | C =>
      show ClassificationMatches E (.neg .C) .uncategorized
      exact True.intro

/-- **E is a reflective reasoner.** It has a sound audit function
    and acknowledges its horizon. -/
def reflectiveE : ReflectiveReasoner E where
  audit := auditE
  audit_sound := auditE_sound
  acknowledges_horizon := ⟨Ext⟩

/-! ## §6. What The Audit Cannot Reach

The audit function classifies propositions of E's vocabulary. It
cannot classify propositions of E' (the extension) that lie
outside E's vocabulary — those are Cell 4 relative to E.

An engine that claims its audit function is *complete* in the
strong sense (classifies every proposition anyone could ever
consider) is implicitly claiming vocabulary completeness. This is
precisely the failure mode from `EpistemicIntegrity §7`: dropping
Cell 4 by pretending the vocabulary is final.

The honest audit is sound but bounded. It classifies what E can
express, and stays silent (or acknowledges the horizon) about
what E cannot.
-/

/-- **The audit is bounded.** For any proposition in the
    extension that is not in E's vocabulary, no proposition of E
    embeds to it. E's audit function's domain is exactly E.Prop_,
    and this theorem shows that domain cannot reach Cell 4
    propositions structurally. -/
theorem audit_domain_is_bounded :
    ∀ q : Ext.E'.Prop_, E.UnknownUnknown Ext q →
      ∀ p : E.Prop_, Ext.embed p ≠ q := by
  intro q hUU p heq
  exact hUU ⟨p, heq⟩

end ReflectiveReasoner
