/-
Composition and Functors of Reasoning Engines
=============================================

Author:  Ido Samuelson
Date:    July 2026
License: CC BY-SA 4.0

Reasoning engines are objects in a category. Extensions form the
morphisms (embeddings preserving derivation). Functors between
engines transport cell membership. This file develops the
categorical structure.

This is standard category-theoretic construction applied to the
`ReasoningEngine` type. No novel content — the identity and
composition laws for extensions and functors are the ordinary
categorical operations. See any category-theory textbook (Awodey,
Mac Lane) for the underlying constructions.

Content:

  • Identity and composition of extensions.
  • Faithful functors between reasoning engines.
  • Cell membership transfers along functors.
  • Composition preserves honesty and reflectiveness.
-/

import EpistemicIntegrity
open EpistemicIntegrity

namespace EpistemicComposition

/-! ## §1. Identity and Composition of Extensions -/

/-- The identity extension: every engine extends itself. -/
def idExtension (E : ReasoningEngine) : ReasoningExtension E where
  E' := E
  embed := id
  embed_injective := by intros; assumption
  preserves_derived := by intros; assumption

/-- **Extensions compose.** If E₁ extends E via Ext₁, and E₂
    extends E₁ via Ext₂, then E₂ extends E. -/
def composeExtension
    {E : ReasoningEngine}
    (Ext₁ : ReasoningExtension E)
    (Ext₂ : ReasoningExtension Ext₁.E') :
    ReasoningExtension E where
  E' := Ext₂.E'
  embed := Ext₂.embed ∘ Ext₁.embed
  embed_injective := by
    intro p q h
    have h1 : Ext₁.embed p = Ext₁.embed q := Ext₂.embed_injective _ _ h
    exact Ext₁.embed_injective _ _ h1
  preserves_derived := by
    intro p h
    exact Ext₂.preserves_derived _ (Ext₁.preserves_derived _ h)

/-! ## §2. Faithful Functors Between Engines -/

/-- A *reasoning functor*: a map between engines preserving
    negation, derivation, and consistency structure. Unlike an
    extension (which requires injectivity), a functor may collapse
    distinct propositions in the source to the same target
    proposition. This is the more general morphism. -/
structure ReasoningFunctor (E₁ E₂ : ReasoningEngine) where
  map               : E₁.Prop_ → E₂.Prop_
  preserves_neg     : ∀ p, map (E₁.Neg p) = E₂.Neg (map p)
  preserves_derived : ∀ p, E₁.Derived p → E₂.Derived (map p)

/-- Identity functor. -/
def idFunctor (E : ReasoningEngine) : ReasoningFunctor E E where
  map := id
  preserves_neg := by intros; rfl
  preserves_derived := by intros; assumption

/-- Composition of functors. -/
def composeFunctor
    {E₁ E₂ E₃ : ReasoningEngine}
    (F : ReasoningFunctor E₁ E₂)
    (G : ReasoningFunctor E₂ E₃) :
    ReasoningFunctor E₁ E₃ where
  map := G.map ∘ F.map
  preserves_neg := by
    intro p
    show G.map (F.map (E₁.Neg p)) = E₃.Neg (G.map (F.map p))
    rw [F.preserves_neg, G.preserves_neg]
  preserves_derived := by
    intro p h
    exact G.preserves_derived _ (F.preserves_derived _ h)

/-! ## §3. Cell Membership Transfer Along Functors -/

/-- **Cell 1 transfers along functors.** If p is Cell-1 in E₁,
    and the functor's target also reports the image as derived,
    then the image is Cell-1 in E₂.

    Note: the target's report condition is a separate hypothesis
    because functors don't automatically carry self-report
    predicates — a functor may preserve derivation without
    preserving reporting. -/
theorem cell1_transfers_along_functor
    {E₁ E₂ : ReasoningEngine}
    (F : ReasoningFunctor E₁ E₂)
    (p : E₁.Prop_)
    (h : E₁.KnownKnown p)
    (target_reports : E₂.Reports_Derived (F.map p)) :
    E₂.KnownKnown (F.map p) :=
  ⟨F.preserves_derived p h.1, target_reports⟩

/-- **Cell 3-latent transfers along functors.** A derivable-but-
    -not-derived proposition in E₁ maps to a proposition in E₂
    that is at least derivable-in-principle. Whether it remains
    Cell 3 in E₂ depends on E₂'s derivation record. -/
theorem cell3_latent_transfers_along_functor
    {E₁ E₂ : ReasoningEngine}
    (F : ReasoningFunctor E₁ E₂)
    (F_preserves_derivable : ∀ p, E₁.Derivable p → E₂.Derivable (F.map p))
    (p : E₁.Prop_)
    (h : E₁.UnknownKnownLatent p)
    (not_derived_target : ¬ E₂.Derived (F.map p)) :
    E₂.UnknownKnownLatent (F.map p) :=
  ⟨F_preserves_derivable p h.1, not_derived_target⟩

/-! ## §4. Composition of Honest Reasoners -/

/-- **Honest reasoners compose along extensions.** If E is honest
    (has an extension), and we have an extension Ext of E, then
    the extension engine Ext.E' is honest iff it too has an
    extension. Honesty at level n+1 requires horizon witness at
    level n+1 — extending from level n doesn't propagate. -/
theorem honesty_composes_along_extension
    (E : ReasoningEngine) (_ : HonestReasoner E)
    (Ext : ReasoningExtension E) :
    HonestReasoner Ext.E' ↔ Nonempty (ReasoningExtension Ext.E') := by
  constructor
  · intro h; exact h.acknowledges_horizon
  · intro h; exact ⟨h⟩

/-- **The identity extension makes any engine trivially honest.**
    Every engine has the identity extension as a witness of its
    own horizon — but this is a degenerate case. It says the
    engine acknowledges "an extension exists" using itself as the
    extension. A serious honesty claim requires a nontrivial
    extension. -/
theorem identity_extension_gives_trivial_honesty
    (E : ReasoningEngine) : HonestReasoner E where
  acknowledges_horizon := ⟨idExtension E⟩

/-! ## §5. Isomorphisms and When Cells Are Preserved

An *isomorphism* between engines is a functor with a two-sided
inverse. Under an isomorphism, all four cell classifications
transfer exactly.
-/

/-- Isomorphism between reasoning engines: functors in both
    directions that compose to identity. -/
structure ReasoningIso (E₁ E₂ : ReasoningEngine) where
  fwd     : ReasoningFunctor E₁ E₂
  bwd     : ReasoningFunctor E₂ E₁
  left_id : ∀ p, bwd.map (fwd.map p) = p
  right_id: ∀ p, fwd.map (bwd.map p) = p

/-- Under an isomorphism, `Derived` transfers in both directions
    (up to the isomorphism). -/
theorem iso_preserves_derived_both
    {E₁ E₂ : ReasoningEngine} (I : ReasoningIso E₁ E₂) (p : E₁.Prop_) :
    E₁.Derived p → E₂.Derived (I.fwd.map p) :=
  I.fwd.preserves_derived p

theorem iso_reflects_derived
    {E₁ E₂ : ReasoningEngine} (I : ReasoningIso E₁ E₂) (q : E₂.Prop_) :
    E₂.Derived q → E₁.Derived (I.bwd.map q) :=
  I.bwd.preserves_derived q

end EpistemicComposition
