/-
Epistemic Integrity: The Four-Cell Framework for Reasoning Engines
==================================================================

Author:  Ido Samuelson
Date:    July 2026
License: CC BY-SA 4.0

A Lean 4 formalization of the requirement that any reasoning engine
capable of honest self-report must articulate its epistemic state
across all four cells:

  Cell 1: Known Known    — derived AND reported as derived
  Cell 2: Known Unknown  — reported as considered-but-undecided
  Cell 3: Unknown Known  — derivable, or derived but unreported
                          (latent or implicit knowledge)
  Cell 4: Unknown Unknown — outside current vocabulary
                          (accessible only from an extension)

The four-cell taxonomy itself is the Rumsfeld matrix, widely used
in decision theory, risk management, and epistemology since being
popularized in 2002. It traces conceptually to Socrates ("I know
that I know nothing"). Prior art:

  • Rumsfeld, D. (2002). Pentagon briefing formulation of the
    four-cell distinction.

  • Taleb, N. N. (2007). "The Black Swan: The Impact of the
    Highly Improbable." Uses the taxonomy for risk classification.

  • Spivack, N. (2025). "Epistemology and Metacognition in
    Artificial Intelligence." Develops the taxonomy for AI systems.

  • Multiple AI safety papers on hallucination detection,
    knowledge boundaries, and epistemic self-report (2023-2026).

The specific application here is formalizing the taxonomy as a
STRUCTURAL requirement on reasoning engines with soundness
conditions on self-report — as opposed to informal descriptive
use. As far as we could search, no dedicated Lean/Coq/Isabelle
formalization of the Rumsfeld matrix as a reasoning-engine
self-report structure existed prior to this file, but the
applications to AI epistemic self-report are substantially
covered in the current literature. Formalizing this in a proof
assistant is a small pedagogical contribution.

The two-form distinction between `UnknownKnownImplicit` (derived
but unreported) and `UnknownKnownLatent` (derivable but not
derived), and the disjointness theorem between them, may be
original to this file. Small technical contribution.

The four cells are the cross-product of two axes:

  Ontology (what is true of the engine): derived / not derived
  Epistemology (what the engine reports): reported / not reported

A reasoning engine that reports only Cell 1 systematically
underrepresents its epistemic state — it lies by omission. A
report is honest when it acknowledges all four cells with correct
classification of propositions the engine has considered.

This is a framework for any reasoning engine, not for any
particular one. It applies to formal proof assistants, to symbolic
reasoners, and — critically — to language models like the one
formalizing this file. The safety and alignment relevance is
direct: a system that cannot articulate its own uncertainty
across all four cells cannot honestly report what it knows, and
the failure mode has a name (hallucination, overconfidence,
underperformance) for each cell it silently drops.

Vanilla Lean 4, no Mathlib. Fully machine-checked. Composes with
the rest of the Provisional Closure library.
-/

namespace EpistemicIntegrity

/-! ## §1. Reasoning Engines with Self-Report -/

/-- A reasoning engine equipped with self-report machinery.

    The `Derivable` predicate captures what the engine could derive
    given its axioms and rules (its deductive closure). The
    `Derived` predicate captures what the engine has *actually*
    derived — the derivation record. `Derived` implies `Derivable`,
    but not conversely: many derivable propositions have not yet
    been derived, and this gap is Cell 3.

    The `Reports_Derived` and `Reports_Undecided` predicates
    capture the engine's self-report: which propositions it
    *claims* to have derived, and which it *claims* to have
    considered without deciding. Both must be sound with respect
    to the actual epistemic state.

    Honesty at this level means: what the engine reports is a
    subset of what is actually true of it. Completeness of report
    is a separate property, discussed in §5. -/
structure ReasoningEngine where
  Prop_               : Type
  Neg                 : Prop_ → Prop_
  Derivable           : Prop_ → Prop
  Derived             : Prop_ → Prop
  Reports_Derived     : Prop_ → Prop
  Reports_Undecided   : Prop_ → Prop
  derived_derivable   : ∀ p, Derived p → Derivable p
  consistent          : ∀ p, ¬ (Derived p ∧ Derived (Neg p))
  report_derived_sound   : ∀ p, Reports_Derived p → Derived p
  report_undecided_sound : ∀ p, Reports_Undecided p →
                              ¬ Derived p ∧ ¬ Derived (Neg p)

namespace ReasoningEngine

/-! ## §2. The Four Cells -/

/-- **Cell 1: Known Known.**
    The engine has derived p AND reports it as derived. This is
    knowledge that is both actual (in the derivation record) and
    articulated (in the report). -/
def KnownKnown (E : ReasoningEngine) (p : E.Prop_) : Prop :=
  E.Derived p ∧ E.Reports_Derived p

/-- **Cell 2: Known Unknown.**
    The engine reports p as considered-but-undecided. Report
    soundness guarantees that reporting p as undecided implies
    p and ¬p are both underived. This is knowledge *of the
    engine's own limits* — the engine knows what it does not
    know, at least regarding p. -/
def KnownUnknown (E : ReasoningEngine) (p : E.Prop_) : Prop :=
  E.Reports_Undecided p

/-- **Cell 3: Unknown Known (derived but unreported).**
    The engine has derived p but does not report it. This is
    knowledge that is actual but unarticulated — the engine
    "knows" p in the sense of having derived it, but cannot
    speak of it in its report. Implicit knowledge. -/
def UnknownKnownImplicit (E : ReasoningEngine) (p : E.Prop_) : Prop :=
  E.Derived p ∧ ¬ E.Reports_Derived p

/-- **Cell 3': Unknown Known (derivable but not derived).**
    A companion notion: p is provable-in-principle but not yet
    in the derivation record. This is *latent* knowledge — the
    engine could reach it, but hasn't. The two versions of
    Cell 3 correspond to the two ways knowledge can be "there
    but not surfaced." -/
def UnknownKnownLatent (E : ReasoningEngine) (p : E.Prop_) : Prop :=
  E.Derivable p ∧ ¬ E.Derived p

/-- The two forms of Cell 3 have a natural relationship: any
    derived proposition is derivable, so any implicit Cell-3
    proposition is not latent. But a derivable proposition may
    fail to be derived (latent Cell 3) without being implicit
    Cell 3. The two carve up different parts of the "not yet
    surfaced" region. -/
theorem cell3_disjoint_by_derivation
    (E : ReasoningEngine) (p : E.Prop_) :
    ¬ (UnknownKnownImplicit E p ∧ UnknownKnownLatent E p) := by
  intro ⟨⟨hD, _⟩, ⟨_, hnD⟩⟩
  exact hnD hD

end ReasoningEngine

/-! ## §3. Extensions and Cell 4 -/

open ReasoningEngine

/-- A *vocabulary extension* of a reasoning engine: a larger engine
    with an injective embedding of the smaller engine's propositions
    into its own, preserving the derivation record. -/
structure ReasoningExtension (E : ReasoningEngine) where
  E'                    : ReasoningEngine
  embed                 : E.Prop_ → E'.Prop_
  embed_injective       : ∀ p q, embed p = embed q → p = q
  preserves_derived     : ∀ p, E.Derived p → E'.Derived (embed p)

namespace ReasoningEngine

/-- **Cell 4: Unknown Unknown.**
    A proposition in an extension E' that has no preimage in E.
    Such a proposition is not expressible in E's vocabulary at
    all — E cannot know it doesn't know it, because it cannot
    even formulate it. Cell 4 is definable only from a vantage
    outside E. -/
def UnknownUnknown
    (E : ReasoningEngine) (Ext : ReasoningExtension E)
    (q : Ext.E'.Prop_) : Prop :=
  ¬ ∃ p : E.Prop_, Ext.embed p = q

end ReasoningEngine

/-! ## §4. Cell Transitions Under Extension -/

/-- **Extension preserves Cell 1.** A proposition that E knows-known
    is also known-known in any extension of E, once the extension
    also reports it. -/
theorem cell1_preserved_under_extension
    {E : ReasoningEngine} (Ext : ReasoningExtension E) (p : E.Prop_)
    (h : E.KnownKnown p)
    (report_extends : Ext.E'.Reports_Derived (Ext.embed p)) :
    Ext.E'.KnownKnown (Ext.embed p) := by
  refine ⟨Ext.preserves_derived p h.1, report_extends⟩

/-- **Cell 3-latent can shift to Cell 1 under extension.** If E
    has a latent theorem p (derivable but not derived), and an
    extension of E both surfaces and reports p, then the pair
    (Cell 3 in E, Cell 1 in Ext) witnesses the transition. The
    theorem returns the pair, not just the endpoint, so the
    transition is a proved arc rather than a claim about the
    final state alone. -/
theorem cell3_latent_can_become_cell1
    {E : ReasoningEngine} (p : E.Prop_)
    (h : E.UnknownKnownLatent p)
    (Ext : ReasoningExtension E)
    (surfaces : Ext.E'.Derived (Ext.embed p))
    (reports : Ext.E'.Reports_Derived (Ext.embed p)) :
    E.UnknownKnownLatent p ∧ Ext.E'.KnownKnown (Ext.embed p) :=
  ⟨h, surfaces, reports⟩

/-- **Cell 4 can shift to Cell 2 under extension.** A proposition
    outside E's vocabulary can become considered-but-undecided in
    an extension that expresses it. The theorem returns the
    transition witness pair: q was Cell 4 in E, q is Cell 2 in
    Ext. -/
theorem cell4_can_become_cell2
    {E : ReasoningEngine} (Ext : ReasoningExtension E)
    (q : Ext.E'.Prop_)
    (h : E.UnknownUnknown Ext q)
    (reported : Ext.E'.Reports_Undecided q) :
    E.UnknownUnknown Ext q ∧ Ext.E'.KnownUnknown q :=
  ⟨h, reported⟩

/-! ## §5. Honest Self-Report

The central results. A reasoning engine's self-report is *honest*
when what it reports as derived is actually derived, and what it
reports as undecided is actually undecided. Both conditions are
already built into the `ReasoningEngine` structure via
`report_derived_sound` and `report_undecided_sound`.

A self-report is *complete* when everything the engine has
actually derived is reported, and everything actually undecided
that the engine has considered is reported as such.

Honesty is baked in; completeness is a separate property whose
failure produces Cells 3 and 4 as observable phenomena.
-/

/-- A report is *complete for Cell 1* if every derived proposition
    is reported as derived. -/
def ReportsCell1Complete (E : ReasoningEngine) : Prop :=
  ∀ p, E.Derived p → E.Reports_Derived p

/-- **Cell 3 is empty iff Cell 1 reporting is complete.** The
    presence of any implicit-Cell-3 proposition is exactly the
    failure of Cell 1 completeness. Underreporting has a name,
    and it is Cell 3. -/
theorem cell3_implicit_empty_iff_cell1_complete
    (E : ReasoningEngine) :
    (∀ p, ¬ E.UnknownKnownImplicit p) ↔ ReportsCell1Complete E := by
  constructor
  · intro h p hD
    apply Classical.byContradiction
    intro hnR
    exact h p ⟨hD, hnR⟩
  · intro h p ⟨hD, hnR⟩
    exact hnR (h p hD)

/-- A report that mentions only Cell 1 (never uses
    `Reports_Undecided`) fails to make Cell 2 knowledge available.
    Any considered-but-undecided proposition becomes invisible. -/
def ReportsOnlyCell1 (E : ReasoningEngine) : Prop :=
  ∀ p, ¬ E.Reports_Undecided p

/-- **A Cell-1-only report cannot articulate any Cell 2 content.**
    This is trivial but names the failure mode. An engine whose
    self-report never uses the "undecided" channel has no Cell 2,
    even if it has genuinely undecided propositions it has
    considered. The considered-undecided knowledge is *lost to
    the report*. -/
theorem cell1_only_erases_cell2
    (E : ReasoningEngine) (h : ReportsOnlyCell1 E) :
    ∀ p, ¬ E.KnownUnknown p :=
  h

/-- **The horizon is not closable from within.** For any engine E
    and any extension of E, there may exist propositions in the
    extension that E cannot express. This is not proven as an
    absolute fact (which would require a diagonal argument at the
    type level) — it is exhibited as the *possibility* that
    extensions carry propositions outside E's reach. Cell 4 is a
    genuine category, not an artifact. -/
theorem cell4_can_be_inhabited
    {E : ReasoningEngine} (Ext : ReasoningExtension E) :
    (∃ q : Ext.E'.Prop_, E.UnknownUnknown Ext q) ∨
    (∀ q : Ext.E'.Prop_, ∃ p : E.Prop_, Ext.embed p = q) := by
  by_cases h : ∀ q : Ext.E'.Prop_, ∃ p : E.Prop_, Ext.embed p = q
  · exact Or.inr h
  · left
    apply Classical.byContradiction
    intro hno
    apply h
    intro q
    apply Classical.byContradiction
    intro hne
    exact hno ⟨q, hne⟩

/-! ## §6. Honest Reasoners

An *honest reasoner* is one whose report acknowledges all four
cells honestly. This does not mean the report is *complete* — no
finite report ever is, because Cell 4 is definable only from
outside — but that the report *distinguishes* the four cells
correctly for propositions it addresses.
-/

/-- An honest reasoner: acknowledges the horizon. The single
    field asserts that at least one extension of E exists — the
    engine does not implicitly claim its vocabulary is complete.

    This is minimum honesty. Stronger honesty conditions (Cell 1
    completeness, Cell 2 completeness) are separately statable
    and provable, but the horizon acknowledgment is the
    irreducible core: without it, the engine cannot be honest
    about Cell 4 by any route. -/
structure HonestReasoner (E : ReasoningEngine) where
  acknowledges_horizon : Nonempty (ReasoningExtension E)

/-- **Honesty at one level does not imply honesty at the next.**
    Being an honest reasoner about E does not automatically make
    Ext.E' an honest reasoner about itself. Ext.E' needs its own
    horizon witness. Honesty is a per-level property, not a
    global one — which matches the recursive structure of the
    extension tower.

    Stated without an `HonestReasoner E` hypothesis because the
    claim is stronger that way: no assumption about E's honesty
    is needed to see that E' 's honesty is a separate matter. -/
theorem honesty_is_local_to_level
    {E : ReasoningEngine} (Ext : ReasoningExtension E) :
    HonestReasoner Ext.E' ↔ Nonempty (ReasoningExtension Ext.E') := by
  constructor
  · intro h; exact h.acknowledges_horizon
  · intro h; exact ⟨h⟩

/-! ## §7. The Safety / Alignment Frame

The four-cell framework is not merely a taxonomy of epistemic
states. It is a requirement on any reasoning engine — including
language models — that claims to honestly report what it knows.
Each cell that a system silently drops corresponds to a named
failure mode:

  • Dropping Cell 2 → the system cannot say "I don't know."
    Manifests as: confident answers to questions the system
    has considered but cannot actually decide.

  • Dropping Cell 3 → the system underreports what it has
    derived (or could derive). Manifests as: repeated
    re-derivation, forgotten intermediate results,
    inconsistency between derivations.

  • Dropping Cell 4 → the system implicitly claims its
    vocabulary is complete. Manifests as: refusal to
    acknowledge questions outside its training distribution,
    or confabulation to fill the gap.

  • Dropping Cell 1 by fabrication → the system reports as
    derived what it has not derived. Manifests as:
    hallucination in the strong sense — claims presented as
    knowledge that have no derivation support.

The last of these is the direct failure of
`report_derived_sound`. A reasoning engine whose report is
sound (Cell 1 is not fabricated) and complete across the
four-cell taxonomy is honest in the strong sense.

pr4xis is designed around this shape. This file states the
requirement at the level of any reasoning engine — pr4xis is one
instance, an LLM would be another, a formal proof assistant a
third. The four cells are what the requirement looks like when
made structural.
-/

end EpistemicIntegrity
