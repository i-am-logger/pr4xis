/-
Gödel's Second Incompleteness Theorem and Self-Application
==========================================================

Author:  Ido Samuelson
Date:    July 2026
License: CC BY-SA 4.0

A vanilla Lean 4 formalization of Gödel's second incompleteness
theorem via the abstract Hilbert–Bernays–Löb derivability
conditions and Löb's theorem, followed by the self-application
argument: any reflective theory strong enough to prove Gödel's
first incompleteness theorem must itself satisfy that theorem's
own incompleteness criterion.

This is STANDARD PROOF THEORY. The self-application argument
in particular is textbook material and has been formalized
before. Prior art:

  • Boolos, G. (1993). "The Logic of Provability." Cambridge
    University Press. The definitive modern treatment of GL and
    the Löb-derived proof of Gödel's second.

  • Franzén, T. (2005). "Gödel's Theorem: An Incomplete Guide
    to Its Use and Abuse." A. K. Peters. Dedicated to precisely
    what the theorem does and does not establish, and to
    correcting popular overclaims — including the observation
    that the metatheory of Gödel's first theorem is itself
    subject to Gödel's second.

  • Smoryński, C. (1985). "Self-Reference and Modal Logic."
    Springer. Contains multiple presentations of the
    self-application and its formalization in GL.

  • Feferman, S. (1962). "Transfinite recursive progressions
    of axiomatic theories." Reflection progressions and the
    tower of extensions arising from self-application.

  • O'Connor, R. (2005). "Essential Incompleteness of Arithmetic
    Verified by Coq." arXiv cs/0505034. Full ~3000-line Coq
    formalization including arithmetization.

  • Paulson, L. C. (2013). "A Machine-Assisted Proof of Gödel's
    Incompleteness Theorems for the Theory of Hereditarily
    Finite Sets." Full Isabelle formalization of both theorems.

  • Maggesi, M. & Perini Brogi, C. (2020). "Mechanising Gödel–Löb
    Provability Logic in HOL Light."

  • FormalizedFormalLogic/Foundation project (Lean 4, ongoing):
    Full formalization including Gödel's second for arithmetic
    theories stronger than IΣ₁. This project is more complete
    than the present file.

The construction here follows the standard modern presentation.
We abstract away the specific arithmetization of syntax and work
with an opaque provability predicate satisfying:

  MP    : Modus ponens (rule of inference)
  AxK   : φ → (ψ → φ)                                 (weakening)
  AxS   : (φ → (ψ → χ)) → ((φ → ψ) → (φ → χ))         (distribution)
  HBL1  : T ⊢ φ  ⟹  T ⊢ □φ                            (necessitation)
  HBL2  : T ⊢ □(φ → ψ) → (□φ → □ψ)                   (internal K)
  HBL3  : T ⊢ □φ → □□φ                               (positive introspection)
  Diag  : ∀ Ψ, ∃ φ, T ⊢ (φ → Ψ φ) ∧ T ⊢ (Ψ φ → φ)   (diagonal lemma)

These are provably satisfied by any theory extending Robinson's Q
(with induction, so Peano Arithmetic in particular). The
formalization here takes them as axioms and derives the theorems
proof-theoretically.

The value of this file within this library is pedagogical clarity
and self-containment — the proof of Löb + Gödel's second + the
self-application argument as a single compact Lean 4 file. It is
NOT a novel contribution.

Vanilla Lean 4, no Mathlib. Fully machine-checked.
-/

namespace GodelSecond

/-! ## §1. The Language -/

/-- Formulas of a minimal language sufficient for the second
    incompleteness theorem: propositional atoms, falsehood,
    implication, and an internal provability predicate □. -/
inductive Formula : Type where
  | atom : Nat → Formula
  | bot  : Formula
  | imp  : Formula → Formula → Formula
  | box  : Formula → Formula
  deriving DecidableEq

open Formula

/-- Negation: ¬φ := φ → ⊥. -/
def neg (φ : Formula) : Formula := imp φ bot

/-- The consistency statement: ¬□⊥, i.e., □⊥ → ⊥. Expresses
    "the theory does not prove falsehood" as a formula of the
    theory's own language. -/
def Con : Formula := imp (box bot) bot

/-! ## §2. The Provability Predicate and Its Axioms -/

/-- Provability in the reflective theory T. Opaque: its behavior
    is fixed by the axioms below, not by any explicit definition. -/
opaque Provable : Formula → Prop

/-- Modus ponens. -/
axiom MP {φ ψ : Formula} : Provable (imp φ ψ) → Provable φ → Provable ψ

/-- Axiom K: φ → (ψ → φ). Weakening for implication. -/
axiom AxK (φ ψ : Formula) : Provable (imp φ (imp ψ φ))

/-- Axiom S: (φ → (ψ → χ)) → ((φ → ψ) → (φ → χ)). Distribution. -/
axiom AxS (φ ψ χ : Formula) :
    Provable (imp (imp φ (imp ψ χ)) (imp (imp φ ψ) (imp φ χ)))

/-- **HBL1 (Necessitation).** If T proves φ, then T proves □φ.
    Reflects that the meta-provability relation is captured by
    the internal predicate. -/
axiom HBL1 {φ : Formula} : Provable φ → Provable (box φ)

/-- **HBL2 (Internal K).** T proves that □ distributes over
    implication. -/
axiom HBL2 (φ ψ : Formula) :
    Provable (imp (box (imp φ ψ)) (imp (box φ) (box ψ)))

/-- **HBL3 (Positive introspection).** T proves that if φ is
    provable, then it is provably provable. -/
axiom HBL3 (φ : Formula) :
    Provable (imp (box φ) (box (box φ)))

/-- **Diagonal Lemma.** For every syntactic construction Ψ of a
    formula from a formula, there exists a fixed point φ that T
    proves equivalent to Ψ(φ). This is provable in PA via
    arithmetization of syntax (Gödel numbering plus the
    representability of substitution); we take it as axiomatic at
    this level of abstraction. -/
axiom Diag (Ψ : Formula → Formula) :
    ∃ φ : Formula,
      Provable (imp φ (Ψ φ)) ∧ Provable (imp (Ψ φ) φ)

/-! ## §3. Propositional Lemmas

Standard derivations from K, S, and MP. These are not the
substantive content of the theorem, but they are the plumbing
without which Löb's proof cannot be written cleanly. -/

/-- Reflexivity of implication: T ⊢ φ → φ. -/
theorem imp_id (φ : Formula) : Provable (imp φ φ) := by
  have h1 : Provable (imp φ (imp (imp φ φ) φ)) := AxK φ (imp φ φ)
  have h2 : Provable (imp (imp φ (imp (imp φ φ) φ))
                          (imp (imp φ (imp φ φ)) (imp φ φ))) :=
    AxS φ (imp φ φ) φ
  have h3 : Provable (imp (imp φ (imp φ φ)) (imp φ φ)) := MP h2 h1
  have h4 : Provable (imp φ (imp φ φ)) := AxK φ φ
  exact MP h3 h4

/-- Transitivity of implication: T ⊢ α → β and T ⊢ β → γ
    give T ⊢ α → γ. -/
theorem imp_trans {α β γ : Formula}
    (h1 : Provable (imp α β))
    (h2 : Provable (imp β γ)) :
    Provable (imp α γ) := by
  have k : Provable (imp (imp β γ) (imp α (imp β γ))) := AxK (imp β γ) α
  have step1 : Provable (imp α (imp β γ)) := MP k h2
  have s : Provable (imp (imp α (imp β γ)) (imp (imp α β) (imp α γ))) :=
    AxS α β γ
  have step2 : Provable (imp (imp α β) (imp α γ)) := MP s step1
  exact MP step2 h1

/-- The S combinator as a derived rule: if T ⊢ α → (β → γ) and
    T ⊢ α → β, then T ⊢ α → γ. -/
theorem imp_s {α β γ : Formula}
    (h1 : Provable (imp α (imp β γ)))
    (h2 : Provable (imp α β)) :
    Provable (imp α γ) := by
  have s : Provable (imp (imp α (imp β γ)) (imp (imp α β) (imp α γ))) :=
    AxS α β γ
  have step1 : Provable (imp (imp α β) (imp α γ)) := MP s h1
  exact MP step1 h2

/-! ## §4. Löb's Theorem

The central technical result. Given the HBL conditions and the
diagonal lemma, if T proves that provability of φ implies φ, then
T proves φ. The proof is the standard one, via a fixed point of
`ξ ↦ (□ξ → φ)`. -/

/-- **Löb's Theorem.** If T ⊢ □φ → φ, then T ⊢ φ. -/
theorem lob (φ : Formula)
    (h : Provable (imp (box φ) φ)) :
    Provable φ := by
  -- By diagonal, obtain ψ with T ⊢ ψ ↔ (□ψ → φ).
  obtain ⟨ψ, hψ_fwd, hψ_bwd⟩ := Diag (fun ξ => imp (box ξ) φ)
  -- hψ_fwd : T ⊢ ψ → (□ψ → φ)
  -- hψ_bwd : T ⊢ (□ψ → φ) → ψ

  -- (1) T ⊢ □(ψ → (□ψ → φ))                             [HBL1 on hψ_fwd]
  have s1 : Provable (box (imp ψ (imp (box ψ) φ))) := HBL1 hψ_fwd
  -- (2) T ⊢ □(ψ → (□ψ → φ)) → (□ψ → □(□ψ → φ))          [HBL2]
  have s2 : Provable (imp (box (imp ψ (imp (box ψ) φ)))
                          (imp (box ψ) (box (imp (box ψ) φ)))) :=
    HBL2 ψ (imp (box ψ) φ)
  -- (3) T ⊢ □ψ → □(□ψ → φ)                              [MP]
  have s3 : Provable (imp (box ψ) (box (imp (box ψ) φ))) := MP s2 s1
  -- (4) T ⊢ □(□ψ → φ) → (□□ψ → □φ)                       [HBL2]
  have s4 : Provable (imp (box (imp (box ψ) φ))
                          (imp (box (box ψ)) (box φ))) :=
    HBL2 (box ψ) φ
  -- (5) T ⊢ □ψ → (□□ψ → □φ)                             [transitivity of (3),(4)]
  have s5 : Provable (imp (box ψ) (imp (box (box ψ)) (box φ))) :=
    imp_trans s3 s4
  -- (6) T ⊢ □ψ → □□ψ                                    [HBL3]
  have s6 : Provable (imp (box ψ) (box (box ψ))) := HBL3 ψ
  -- (7) T ⊢ □ψ → □φ                                     [imp_s on (5),(6)]
  have s7 : Provable (imp (box ψ) (box φ)) := imp_s s5 s6
  -- (8) T ⊢ □ψ → φ                                      [transitivity of (7), hyp]
  have s8 : Provable (imp (box ψ) φ) := imp_trans s7 h
  -- (9) T ⊢ ψ                                           [MP on hψ_bwd and (8)]
  have s9 : Provable ψ := MP hψ_bwd s8
  -- (10) T ⊢ □ψ                                         [HBL1 on (9)]
  have s10 : Provable (box ψ) := HBL1 s9
  -- (11) T ⊢ φ                                          [MP on (8) and (10)]
  exact MP s8 s10

/-! ## §5. Gödel's Second Incompleteness Theorem

An immediate consequence of Löb's theorem: if T is consistent,
then T does not prove its own consistency statement. -/

/-- **Gödel's Second Incompleteness Theorem.**
    If T is consistent (T ⊬ ⊥), then T ⊬ Con, where
    Con := □⊥ → ⊥. -/
theorem godel_second (consistent : ¬ Provable bot) : ¬ Provable Con := by
  intro hCon
  -- hCon : Provable (imp (box bot) bot)  — which is exactly Löb's hypothesis for φ = ⊥.
  have hBot : Provable bot := lob bot hCon
  exact consistent hBot

/-! ## §6. The Self-Application Argument

Any framework M capable of proving Gödel's first incompleteness
theorem contains PA (or an equivalent) as a subtheory. M
therefore satisfies HBL1–HBL3 with respect to its own provability
predicate; the diagonal lemma is provable in M. By the theorem
above, M does not prove its own consistency. But M's consistency
is a genuine claim expressible in M — and, by hypothesis, true
(M is being used to prove theorems, so it had better be
consistent).

M therefore contains a formula (Con) that:

  (a) is true (M is consistent by hypothesis),
  (b) is not provable in M (by godel_second).

This is precisely the criterion Gödel's first incompleteness
theorem uses to conclude that a theory is incomplete: existence
of a true, unprovable sentence.

M therefore satisfies its own incompleteness criterion. The
framework in which Gödel's first theorem is proved is itself
subject to that theorem's verdict. This is the self-application
argument, now with real proof-theoretic content. -/

/-- **Self-Application: The Theorem's Framework Is Incomplete
    by Its Own Criterion.**

    Given consistency, we exhibit a formula Con of the theory
    such that:

      (a) `¬ Provable Con`     — Con is not derivable in the theory.
      (b) `¬ Provable bot`     — the theory is consistent, which is
                                  what Con expresses at the meta level.

    The pair witnesses the theory's own incompleteness by the
    same criterion Gödel's first theorem invokes: there is a
    true sentence (the theory's consistency, expressed by Con)
    that the theory does not prove. -/
theorem godel_criterion_self_application
    (consistent : ¬ Provable bot) :
    (¬ Provable Con) ∧ (¬ Provable bot) :=
  ⟨godel_second consistent, consistent⟩

/-! ## §7. Concluding Remark

The chain of reasoning:

  • The Hilbert-Bernays-Löb conditions + diagonal lemma
    ⟹ Löb's theorem (§4).
  • Löb's theorem ⟹ Gödel's second incompleteness (§5).
  • Gödel's second, applied to the framework in which
    Gödel's first is proved, ⟹ the framework itself
    satisfies Gödel's first's criterion (§6).

The syntactic content of Gödel's theorem stands. What the file
establishes is that the framework which announces the theorem is
subject to the theorem's own verdict: it too contains a true
statement (its own consistency) that it does not prove.

This is not a critique of the proof of Gödel's first theorem.
The proof is correct. The critique is of the *scope claim* that
often accompanies the popular presentation — that the theorem
somehow diagnoses a limit on reasoning-in-general while itself
standing above that limit. It does not stand above; it stands
inside, and Löb's theorem plus Gödel's second, applied to the
meta-level, exhibit exactly how.

Nothing in this file uses classical logic, choice, or Mathlib.
The proofs go through in intuitionistic Lean 4 given the
abstract axioms. If the axioms hold of a concrete arithmetic
theory (they hold of PA and its extensions), the theorems apply
to that theory concretely.
-/

end GodelSecond
